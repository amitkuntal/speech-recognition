import pyttsx
import pyaudio
import wave
import speech_recognition as sr
from commands import Commander

running =True

def say(text):
    engine = pyttsx.init()
    engine.say(text)
    engine.runAndWait()
def play_audio(filename):
    chunk=1024
    wf = wave.open(filename,'rb')
    pa=pyaudio.PyAudio()

    stream=pa.open(
        format=pa.get_format_from_width(wf.getsampwidth()),
        channels =wf.getnchannels(),
        rate=wf.getframerate(),
        output=True
    )
    data_stream =wf.readframes(chunk)
    while data_stream:
        stream.write(data_stream)
        data_stream=wf.readframes(chunk)

    stream.close()
    pa.terminate()
play_audio("./audio/Bi.wav")

r= sr.Recognizer()
cmd=Commander()
def initSpeech():
    print("Listening..........")
    play_audio("./audio/Bi.wav")
    with sr.Microphone() as source:
        print("Say something........")
        audio=r.listen(source)

    play_audio("./audio/Ai.wav")

    command = ""

    try:
        command = r.recognize_google(audio)
    except:
        say("Sorry I Could not understand you ....")

    print("Your commnad")
    print(command)

    if command in ["quit","bye","good bye","exit","tata"]:
        global running
        running=False
        say("Its Good time with you. wish to meet you soon...")

    cmd.discover(command)
    #say(command)
while running == True:
    initSpeech()





