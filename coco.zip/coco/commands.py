import subprocess
import os
import pyttsx
from bs4 import BeautifulSoup
from .get_answer import Fetcher

class Commander:
    def __init__(self):
        self.confirm =["yes","affirmative","si","sure","do it","yeah","confirm"]
        self.cancel = ["no","negative","negative solder","don't","wait","cancel"]

    def discover(self,text):
        if "what" in text and "name" in text:
            if "my kfjkdj" in text:
                self.respond("You did not tell me your name yet")
            else:
                self.respond("My name is Coco. what is your name?")
        elif "who are you" in text or "what are you" in text:
            self.respond("I am a computer program. Or you can call me CoCo.")
        elif "how are you" in text:
            self.respond("I am fine dear")
        elif "who developed you" in text or "who is your creator" in text or "your founder" in text:
            self.respond("My founder is Mr. Amit Singh Kuntal")
        elif "which technology you use" in text or "your developed language" in text or "language you used" in text:
            self.respond("You Can not ask me questing like this. By the way i am written in python3.currently i am in developement mode")
        elif "launch" in text or "open" in text:
            app =text.split(" ", 1)[-1]
            self.respond("Oppening " +app)
            os.system("start " + app)
        elif "my name is " in text:
            app = text.split(" ",-1)[-1]
            self.respond("Nice name "+app)
        # else:
        #     f =Fetcher("https://www.google.co.in/search?q="+text)

    def respond(self,response):
        print(response)
        engine = pyttsx.init()
        engine.say(response)
        engine.runAndWait()
